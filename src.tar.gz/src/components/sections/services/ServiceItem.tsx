'use client'

import React, { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import Link from 'next/link'
import Container from '@/components/atoms/Container'
import Section from '@/components/atoms/Section'
import { Sparkles, ArrowUpRight } from 'lucide-react'
import MorphSlider from '@/components/Animation/Morph'
import { SERVICES_DATA, ServiceItem as ServiceItemType } from '@/components/sections/services/Service'

type ServicesTeaserProps = {
  eyebrow?: string
  heading?: string
  services?: ServiceItemType[]
  defaultActiveId?: string
  fullServicesHref?: string
}

const ServicesTeaser = (props: ServicesTeaserProps) => {
  const eyebrow = props.eyebrow || '(Services)'
  const heading = props.heading || 'WHAT WE BUILD.'
  const services = props.services || SERVICES_DATA
  const fullServicesHref = props.fullServicesHref || '/services'

  const activeInitialId = props.defaultActiveId || services[0]?.id || 'brand-identity'
  const [activeTab, setActiveTab] = useState(activeInitialId)

  const activeIndex = services.findIndex((s) => s.id === activeTab)
  const activeService = services[activeIndex] || services[0]
  const marqueeList = services.map((s) => s.label)
  
  const marqueeItems = [...marqueeList, ...marqueeList, ...marqueeList, ...marqueeList]

  // Stable reference — without this, MorphSlider's engine gets torn down
  // and rebuilt (back to slide 0) on every hover, since .map() otherwise
  // creates a new array every render.
  const morphItems = useMemo(
    () => services.map((s) => ({ image: s.image, caption: s.title })),
    [services]
  )

  return (
    <Section className='relative w-full bg-surface-page text-heading  overflow-hidden flex flex-col justify-between transition-colors duration-300'>

      {/* Header + CTA Button — unchanged */}
      <Container className='w-full z-10 flex flex-col sm:flex-row items-center sm:items-center justify-between gap-6'>
        <div>
          <span className='text-xs md:text-small tracking-tight text-caption block mb-2 font-mono'>
            {eyebrow}
          </span>
          <h2 className='text-size-h2 md:text-size-h1 font-extrabold tracking-wider text-caption font-primary'>
            {heading}
          </h2>
        </div>

        <Link
          href={fullServicesHref}
          className='group relative inline-flex items-center gap-3 px-6 py-3 rounded-full bg-primary text-white font-medium text-small overflow-hidden transition-all duration-300 shadow-md hover:shadow-xl hover:shadow-primary/20 hover:-translate-y-0.5'
        >
          <span className='relative z-10 font-semibold text-size-caption tracking-wide'>Explore All Services</span>
          <motion.div
            animate={{ x: [0, 3, 0], y: [0, -3, 0] }}
            transition={{ repeat: Infinity, duration: 2, ease: 'easeInOut' }}
            className='relative z-10 flex items-center justify-center'
          >
            <ArrowUpRight className='w-4 h-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5' />
          </motion.div>
        </Link>
      </Container>

      {/* Navigation Tabs — unchanged, still onClick + onMouseEnter */}
      <Container className='w-full z-10 flex flex-wrap  whitespace-nowrap sm:flex-row items-start pt-6 mt-6  justify-between gap-6'>
        {services.map((service) => {
          const isActive = service.id === activeTab
          return (
            <div key={service.id} className='flex items-center justify-center'>
              <button
                onMouseEnter={() => setActiveTab(service.id)}
                onClick={() => setActiveTab(service.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-full whitespace-nowrap shrink-0 text-size-caption md:text-size-caption text-bold transition-colors duration-200 cursor-pointer ${
  isActive ? 'bg-primary text-white' : ' border border-border-subtle/80 text-caption hover:bg-surface-section/90'
                }`}
              >
                {isActive && <span className='w-2 h-2 rounded-full bg-success shrink-0' />}
                <span>{service.label}</span>
              </button>
            </div>
          )
        })}
      </Container>

      {/* Visual Preview — marquee unchanged; image block is now MorphSlider */}
      <div className='relative w-full flex items-center justify-center min-h-105 my-4'>
        <div className='absolute inset-0 flex items-center overflow-hidden pointer-events-none z-0'>
          <motion.div
            animate={{ x: ['0%', '-35%'] }}
            transition={{ duration: 60, ease: 'linear', repeat: Infinity }}
            className='whitespace-nowrap flex items-center gap-8 md:gap-12 select-none'
          >
            {marqueeItems.map((title, index) => (
              <div key={index} className='flex items-center gap-8 md:gap-12'>
                <Sparkles className='w-6 h-6 sm:w-10 sm:h-10 shrink-0 text-primary' />
                <span className='text-[3.5rem] sm:text-[6.5rem] lg:text-[7rem] font-bold text-heading/70 leading-none tracking-tight font-primary'>
                  {title}
                </span>
              </div>
            ))}
          </motion.div>
        </div>

        <Link
          href={fullServicesHref}
          className='z-10 relative w-85 sm:w-120 h-70 sm:h-90 rounded-3xl overflow-hidden shadow-2xl border border-border-subtle group cursor-pointer block'
        >
          <MorphSlider
            items={morphItems}
            activeIndex={activeIndex}
            onIndexChange={(i:number) => setActiveTab(services[i]?.id)}
            autoplay
            autoplayDelay={4}
            transition='melt'
            radius={24}
            showCaptions={false}
            showControls={false}
            showIndicators={false}
            className='w-full h-full'
          />

          <div className='absolute inset-0 bg-linear-to-t from-dark-500/80 via-transparent to-transparent flex items-end p-6 pointer-events-none z-20'>
            <div className='flex items-center justify-between w-full text-white'>
              <span className='font-bold  text-white text-size-body'>{activeService.title}</span>
              <span className='text-size-caption font-secondary tracking-wider flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary text-white font-medium shadow-sm whitespace-nowrap shrink-0'>
                View Details <ArrowUpRight className='w-3.5 h-3.5' />
              </span>
            </div>
          </div>
        </Link>
      </div>

    </Section>
  )
}

export default ServicesTeaser