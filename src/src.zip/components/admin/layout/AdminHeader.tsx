import Link from 'next/link'
import { ArrowUpRight } from 'lucide-react'

export default function AdminHeader() {
  return (
    <header className="flex min-h-16 items-center justify-between border-b border-border-subtle bg-surface-page px-5 sm:px-8">
      <p className="text-sm font-medium text-heading">Content workspace</p>
      <Link href="/" className="inline-flex items-center gap-2 text-sm text-caption hover:text-heading">
        View website <ArrowUpRight aria-hidden="true" className="h-4 w-4" />
      </Link>
    </header>
  )
}