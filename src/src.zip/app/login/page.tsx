import AdminPlaceholderPage from '@/components/admin/AdminPlaceholderPage'

export default function AdminLoginPage() {
	return (
		<AdminPlaceholderPage
			title="Admin sign-in"
			description="Authentication has not been configured for this workspace."
		/>
	)
}
