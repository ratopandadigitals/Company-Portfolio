import AdminPlaceholderPage from '@/components/admin/shared/AdminPlaceholderPage'

const NewWorkPage=() => {
	return 
	<AdminPlaceholderPage title="New work" description="Project creation is not connected yet." />
}
export default NewWorkPage
