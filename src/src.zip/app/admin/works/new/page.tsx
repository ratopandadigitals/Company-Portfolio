import AdminPlaceholderPage from '@/components/admin/AdminPlaceholderPage'

export default function NewWorkPage() {
	return <AdminPlaceholderPage title="New work" description="Project creation is not connected yet." />
}
