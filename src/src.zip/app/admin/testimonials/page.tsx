import AdminPlaceholderPage from '@/components/admin/shared/AdminPlaceholderPage'

const TestimonialsPage = () => {
return (
     <AdminPlaceholderPage
 		title="Testimonials"
 		description="Manage client testimonials and website statistics."
 	/>
)
}

export default TestimonialsPage
