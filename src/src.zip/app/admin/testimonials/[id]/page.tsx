import AdminPlaceholderPage from '@/components/admin/shared/AdminPlaceholderPage'

const EditTestimonialPage = () => {
return ( <AdminPlaceholderPage
 		title="Edit testimonial"
 		description="Testimonial editing is not connected yet."
 	/>
)
}

export default EditTestimonialPage
