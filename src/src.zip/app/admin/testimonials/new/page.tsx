import AdminPlaceholderPage from '@/components/admin/shared/AdminPlaceholderPage'

const NewTestimonialPage = () => {
return ( <AdminPlaceholderPage
 		title="New testimonial"
 		description="Testimonial creation is not connected yet."
 	/>
)
}

export default NewTestimonialPage
