import AdminPlaceholderPage from '@/components/admin/AdminPlaceholderPage'

export default function NewServicePage() {
	return <AdminPlaceholderPage title="New service" description="Service creation is not connected yet." />
}
