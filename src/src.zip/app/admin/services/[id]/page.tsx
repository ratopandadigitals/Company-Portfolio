import AdminPlaceholderPage from '@/components/admin/AdminPlaceholderPage'

export default function EditServicePage() {
	return <AdminPlaceholderPage title="Edit service" description="Service editing is not connected yet." />
}
