import type { ReactNode } from 'react'
import AdminHeader from '@/components/admin/layout/AdminHeader'
import AdminSidebar from '@/components/admin/layout/AdminSidebar'

export default function AdminLayout({ children }: { children: ReactNode }) {
	return (
		<div className="min-h-screen bg-surface-page lg:flex">
			<AdminSidebar />
			<div className="min-w-0 flex-1">
				<AdminHeader />
				<main className="mx-auto w-full max-w-7xl p-5 sm:p-8">{children}</main>
			</div>
		</div>
	)
}
