import AdminPlaceholderPage from '@/components/admin/AdminPlaceholderPage'

export default function EditEventPage() {
	return <AdminPlaceholderPage title="Edit event" description="Event editing is not connected yet." />
}
