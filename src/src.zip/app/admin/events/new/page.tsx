import AdminPlaceholderPage from '@/components/admin/AdminPlaceholderPage'

export default function NewEventPage() {
	return <AdminPlaceholderPage title="New event" description="Event creation is not connected yet." />
}
